- The steps below assume that stakeholders of this assignment already have python3 and pip3
  installed on your machine.

Installation, Set-Up, and Execution Steps:
 1. Download "Perpay Take Home Challenge.zip"
 2. Unzip file and open the project in Visual Studio Code
 3. Open Terminal ("Terminal 1")
 4. In Terminal 1, enter "cd perpay_takehome/perpay-payment-metrics"
 5. In Terminal 1, enter "npm i"
 6. Open another terminal ("Terminal 2")
 7. In Terminal 2, enter "source perpay_takehome/bin/activate"
 8. In Terminal 2, enter "perpay_takehome/perpay-payment-metrics/server/companydata/"
 9. In Terminal 2, enter "pip3 install -r requirements.txt"
 9. In Terminal 2, enter "python3 manage.py runserver"
10. In Terminal 1, enter "npm start"

Useful sites:
 - Django Rest Framework Portal: http://127.0.0.1:8000/
 - Admin Portal: http://127.0.0.1:8000/admin/
    - Admin Credentials:
      username: admin
      email: admin@email.com
      Password: adminadmin123321

Developer Notes:
 - Since it's been some time since the last time I did web development, I spent the first day or
   two watching videos and reading articles about ReactJS and MaterialUI to refresh my memory on
   good coding habits (such as functional components as opposed to class-based ones), react
   hooks, and more. Furthermore, as Django was brand new to me, I spent some time reading up on
   utilizing it and understanding how it works. Once I felt ready to go, I began development.
   Due to the fact that I have other classes and senior design work to do parallel to this
   assignment, I worked on it incrementally over the span of the two weeks. Throughout the
   process, I came to realize and understand several different things, and really had a fun time
   working on this. If I had more time, the first thing I would do is consider what elements of
   the code I can re-factor so that they work more optimally. Regarding expanding on the
   functionality, a few examples include: adding the ability to submit payments through the UI,
   making the column names of all the tables clickable to open other pages that presented more
   specific information regarding the column they selected, and perhaps introduced searching
   capability and pagination to the Breakdown table, so that if there was too much data for one
   screen, users can find data for a specific company if they so desire and promote a better
   user experience.
 - If you would like to add more data to the website, it's easiest to do so through the Admin
   Portal I provided above. Refresh webpage to see changes.
 - If you would like to see what the webpage looks like without any data being served to it,
   simply terminate the server by entering "Ctrl+C" in Terminal 2. Refresh webpage to see
   changes.