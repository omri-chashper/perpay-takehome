from .serializers import CompanySerializer, UserSerializer, PaymentSerializer
from .models import Company, User, Payment
from django.http import HttpResponse
from rest_framework import viewsets, permissions, status
from rest_framework.response import Response

class CompanyViewSet(viewsets.ModelViewSet):
    queryset = Company.objects.all().order_by('name')
    serializer_class = CompanySerializer
    permission_classes = [permissions.AllowAny]


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all().order_by('name')
    serializer_class = UserSerializer
    permission_classes = [permissions.AllowAny]

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all().order_by('payment_date')
    serializer_class = PaymentSerializer
    permission_classes = [permissions.AllowAny]