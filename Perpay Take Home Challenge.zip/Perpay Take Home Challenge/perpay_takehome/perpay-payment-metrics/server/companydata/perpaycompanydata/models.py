from django.db import models
from django.contrib.auth.hashers import make_password

class Company(models.Model):
    name = models.CharField(max_length=25)

    def __str__(self):
        return self.name

class User(models.Model):
    name = models.CharField(max_length=30)
    email = models.CharField(max_length=45)
    password = models.CharField(max_length=365)
    password_hashed = models.CharField(max_length=365, default=None, blank=True, null=True)

    def save(self, *args, **kwargs):
        # Hash the password before saving
        self.password_hashed = make_password(self.password)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

class Payment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=19, decimal_places=2)
    payment_date = models.DateField("Payment Date")

    def __str__(self):
        return f"${self.amount} on {self.payment_date:%x} by {self.user} for {self.company}"
