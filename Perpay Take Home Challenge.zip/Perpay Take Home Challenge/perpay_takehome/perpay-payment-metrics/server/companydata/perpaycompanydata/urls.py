from django.urls import path
from .views import CompanyViewSet, UserViewSet, PaymentViewSet

urlpatterns = [
    path("companies", CompanyViewSet, name="companies"),
    path("users", UserViewSet, name="users"),
    path("payments", PaymentViewSet, name="payments")
]