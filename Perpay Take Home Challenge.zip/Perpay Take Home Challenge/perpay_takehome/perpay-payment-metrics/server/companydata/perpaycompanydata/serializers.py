from .models import Company, User, Payment
from rest_framework import serializers

class CompanySerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Company
        fields = ['name']

class UserSerializer(serializers.HyperlinkedModelSerializer):
    company_name = serializers.CharField(source='company.name', read_only=True)
    class Meta:
        model = User
        fields = ['name', 'email', 'password', 'password_hashed', 'company_name']

class PaymentSerializer(serializers.HyperlinkedModelSerializer):
    user_name = serializers.CharField(source='user.name', read_only=True)
    company_name = serializers.CharField(source='company.name', read_only=True)
    class Meta:
        model = Payment
        fields = ['user_name', 'company_name', 'amount', 'payment_date']