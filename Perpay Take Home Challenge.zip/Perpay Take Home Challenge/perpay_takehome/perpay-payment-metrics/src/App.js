import React, { useEffect, useState } from 'react';
import './Styling/App.css';
import SummaryBox from './Components/SummaryBox';
import BreakdownTable from './Components/BreakdownTable';

function useTotalDollarsPaid(data) {
  var totalDollarsPaid = 0.00;

  if (data)
  {
    var all_payment_history = data;
    var total = 0.0; 

    all_payment_history.forEach(element => {
      total += parseFloat(element.amount);        
    })
    
    totalDollarsPaid = total;
  }

  return totalDollarsPaid.toLocaleString('en-US', {style:"currency", currency:"USD"});
}

function usePaymentBreakdown(data) {
  var total_paid_users = new Set();
  var total_companies = new Set();

  if (data) {
    data.forEach(element => {
      if (!(element.user_name in total_paid_users)) {
        total_paid_users.add(element.user_name);
      }

      if (!(element.company_name in total_companies)) {
        total_companies.add(element.company_name);
      }
    })
  }

  return (total_paid_users && total_companies) ? [total_paid_users.size, total_companies.size] : [0,0];
}

function App() {
  const [payments, setPayments] = useState([]);
  useEffect(() => {
    fetch('http://127.0.0.1:8000/payments/', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(resp => resp.json()).then(resp => setPayments(resp)).catch(error => console.log(error));
  }, []);

  // variables
  var total_dollars_paid = useTotalDollarsPaid(payments.results);
  var payment_breakdown_res = usePaymentBreakdown(payments.results);

  return (
    <div className="App">
      <div className="App-header">
        <h1>Perpay Payment Metrics</h1>
      </div>
      <div className="App-body">
        <div className="Net-Summaries">
          <div style={{margin:'10px'}}>
            <SummaryBox title="Total Dollars Paid" data={total_dollars_paid}/>
          </div>
          <div style={{margin:'10px'}}>
            <SummaryBox title="Total Number of Payments" data={payments.count ? payments.count.toString() : 0}/>
          </div>
          <div style={{margin:'10px'}}>
            <SummaryBox title="Payment Breakdown" data={`${payment_breakdown_res[0]} paying users from ${payment_breakdown_res[1]} companies`}/>
          </div>
        </div>
        <div className="Breakdown">
            <h2>Company Breakdown</h2>
            <BreakdownTable data={payments}/>
        </div>
      </div>
    </div>
  );
}

export default App;
