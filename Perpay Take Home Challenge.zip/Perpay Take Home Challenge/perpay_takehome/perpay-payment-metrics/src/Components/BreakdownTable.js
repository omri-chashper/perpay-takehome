import React, { useEffect, useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import '../Styling/BreakdownTable.css';

function arrange_data(data) {
    var arr_data = {};

    data.forEach(element => {
        if (!(element.company_name in arr_data))
        {
            arr_data[element.company_name] = {users : new Set().add(element.user_name), total_payments : 1, total_paid : parseFloat(element.amount)};
        }
        else
        {
            arr_data[element.company_name].users.add(element.user_name);
            arr_data[element.company_name].total_payments++;
            arr_data[element.company_name].total_paid += parseFloat(element.amount);
        }
    });

    // convert to list of objects to match type of payments.results
    var arr_data_list = Object.entries(arr_data).map((e) => ( { [e[0]]: e[1] } ));

    console.log(arr_data_list);

    return arr_data_list;
}

export default function BreakdownTable(params) {
    const [data_set, setData] = useState([]);

    useEffect(() => {
        if (params.data.results) {
            setData(arrange_data(params.data.results));
        }
    }, [params]);

    return (
        <TableContainer className='Container'>
            <Table className='Table' aria-label="simple table">
                <TableHead>
                    <TableRow>
                        <TableCell className='CompNameHeader'>Company Name</TableCell>
                        <TableCell className='CompDataHeader'>Dollars Paid</TableCell>
                        <TableCell className='CompDataHeader'>Number of Payments</TableCell>
                        <TableCell className='CompDataHeader'>Paying Users</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {params.data.count > 0 ? (
                        data_set.map((list, index) => (
                            <TableRow key={index}>
                                <TableCell className='CompNameValue'>{Object.keys(list)[0]}</TableCell>
                                <TableCell className='CompDataValue'>{list[Object.keys(list)[0]].total_paid.toLocaleString('en-US', {style:"currency", currency:"USD"})}</TableCell>
                                <TableCell className='CompDataValue'>{list[Object.keys(list)[0]].total_payments}</TableCell>
                                <TableCell className='CompDataValue'>{list[Object.keys(list)[0]].users.size}</TableCell>
                            </TableRow>
                        ))
                    ) : (
                        <TableRow>
                            <TableCell className='CompNameValue'> No Companies Registered</TableCell>
                            <TableCell className='CompDataValue'>$0.00</TableCell>
                            <TableCell className='CompDataValue'>0</TableCell>
                            <TableCell className='CompDataValue'>0</TableCell>
                        </TableRow>
                    )}
                </TableBody>
            </Table>
        </TableContainer>
    );
}